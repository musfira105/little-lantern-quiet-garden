LITTLE LANTERN: THE QUIET GARDEN
A cozy exploration game.

HOW TO PLAY
- Move with WASD or arrow keys.
- Press E or Space to collect moon-petals or speak to the lantern keeper.
- On touchscreens, use the on-screen controls.
- Find all 7 moon-petals, then return to the keeper by the pond.

ITCH.IO
1. Create a new project on itch.io and choose HTML as the project kind.
2. Upload this ZIP file.
3. Enable “This file will be played in the browser”.
4. Save and preview your page.

The game is self-contained and uses no external assets or libraries.
